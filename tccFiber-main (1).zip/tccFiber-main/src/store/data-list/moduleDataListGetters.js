/*=========================================================================================
  File Name: moduleCalendarGetters.js
  Description: Calendar Module Getters

==========================================================================================*/


export default {
  // getItem: state => (productId) => state.products.find((product) => product.id == productId),
}
