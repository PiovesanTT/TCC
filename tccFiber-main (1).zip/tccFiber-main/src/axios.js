// axios
import axios from 'axios'

const baseURL = ""

export default axios.create({
  baseURL: baseURL
  // You can add your headers here
})
